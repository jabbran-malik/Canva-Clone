"use client";

import { SidebarItem } from "@/features/editor/components/sidebar-item";
import { LayoutTemplate, ImageIcon, Settings, Shapes, Sparkles, Type } from "lucide-react";
import { ActiveTool } from "@/features/editor/types";
interface SidebarProps {
  activeTool: ActiveTool
  onChangeActiveTool: (tool: ActiveTool) => void ;
}

export const Sidebar = ({
  activeTool,
  onChangeActiveTool,
}:SidebarProps) => {
  return (
    <aside className="bg-white flex flex-col w-[100px] h-full border-r overflow-y-auto">
      <ul className="flex flex-col">
        <SidebarItem
          icon={LayoutTemplate}
          label='Design'
          isActive={activeTool === "templates"}
          onClick={() => {onChangeActiveTool("templates") }} />
        <SidebarItem
          icon={ImageIcon}
          label='image'
          isActive={activeTool === "images"}
          onClick={() => {onChangeActiveTool("images") }} />
        <SidebarItem
          icon={Type}
          label='text'
          isActive={activeTool === "text"}
          onClick={() => {onChangeActiveTool("text") }} />
        <SidebarItem
          icon={Shapes}
          label='shapes'
          isActive={activeTool === "shapes"}
          onClick={() => {onChangeActiveTool("shapes") }} />
        <SidebarItem
          icon={Sparkles}
          label='AI'
          isActive={activeTool === "ai"}
          onClick={() => {onChangeActiveTool("ai") }} />
        <SidebarItem
          icon={Settings}
          label='Settings'
          isActive={activeTool === "settings"}
          onClick={() => {onChangeActiveTool("settings") }} />
      </ul>
    </aside>
  );
};
